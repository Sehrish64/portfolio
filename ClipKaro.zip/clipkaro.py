#!/usr/bin/env python3
"""
ClipKaro v1.6 — free, fully local AI clipping tool (Urdu-first).

Turns a long video into 2-3 vertical (9:16, 1080x1920) Shorts with:
  * static reframe  — SOLID pad (v1.3): the full source frame sits centred
                      over a flat, unchanging solid background (#0B0B10).
                      No blurred mirror (v1.2's blurred pad still moved on
                      screen — Sehrish's feedback), no tracking crop, no
                      panning, no punch-in zooms.
  * virality score  — 0-100 per clip WITH plain-language reasons
  * subtitles — ON by default in sahi Roman Urdu (v1.6, Sehrish's
                      order 2026-11-18: "log subtitles dekhna chahte
                      hain — 100% theek hon tab hi chalega"). Karaoke
                      captions in LATIN script only, transliterated
                      locally from the transcript; --captions off /
                      roman-hindi bhi maujood. The auto hook title +
                      posting draft are still saved as editable
                      .title.txt / .post.txt.

Usage:
    python clipkaro.py <input_long_video> [--clips 3] [--min-len 30]
                       [--max-len 60] [--reframe auto|crop|pad]
                       [--language auto|ur|en|...]
                       [--captions off|roman-urdu|roman-hindi]
                       [--model tiny|small|medium|large-v3]

Everything is local: ffmpeg + faster-whisper. No network, no keys.
Transcription model is configurable via --model (v1.4, Sehrish's order:
"bra model use krle" — the DEFAULT is now medium; large-v3's download
is blocked by this VM's disk quota, tiny stays selectable). Transcript
caches are keyed by model name, so a tiny transcript is never silently
reused as a big-model one.
Outputs: ./output/<name>-shortN.mp4, <name>-shortN.title.txt,
         <name>-shortN.post.txt and one clips.json for the whole run.
"""

import argparse
import json
import math
import os
import re
import subprocess
import sys
import time
import wave

# ---------------------------------------------------------------------------
# Environment fixes (learned the hard way — see AGENTS.md):
# 1) The runtime's proxy env vars crash httpx/HF imports. Strip them all
#    before importing anything that might read them.
for _k in list(os.environ):
    if "proxy" in _k.lower():
        del os.environ[_k]
# Public edition: model downloads from HuggingFace on first run if not cached.

# 2) faster-whisper lives in its own venv. If we were launched with a python
#    that can't import it, re-exec ourselves with the venv python.
#    NOTE: the venv python is a symlink to the system python, so detect the
#    venv via sys.prefix (honours pyvenv.cfg), never realpath(sys.executable).
VENV_PY = os.path.expanduser("~/workspace/.venv-whisper/bin/python")
try:
    import faster_whisper  # noqa: F401
except ImportError:
    _in_venv = sys.prefix != getattr(sys, "base_prefix", sys.prefix)
    if (os.path.exists(VENV_PY) and not _in_venv
            and not os.environ.get("CLIPKARO_REEXEC")):
        os.environ["CLIPKARO_REEXEC"] = "1"
        os.execv(VENV_PY, [VENV_PY, os.path.abspath(__file__), *sys.argv[1:]])
    raise

import numpy as np  # noqa: E402
from faster_whisper import WhisperModel  # noqa: E402

def _snapshot(repo):
    """Newest local HF snapshot dir for a Systran faster-whisper repo
    that actually contains model.bin."""
    base = os.path.expanduser(f"~/.cache/huggingface/hub/models--Systran--{repo}/snapshots")
    if not os.path.isdir(base):
        return None
    cands = [os.path.join(base, d) for d in sorted(os.listdir(base), reverse=True)
             if os.path.exists(os.path.join(base, d, "model.bin"))]
    return cands[0] if cands else None


# Transcription models (v1.4). Sehrish: "bra model use krle" — the
# default is now MEDIUM (769M params, ~20x tiny). large-v3 was tried
# first (2026-11-17) but its 3.1 GB model.bin download failed twice
# with "Disk quota exceeded" (EDQUOT) on this VM, while medium was
# already fully cached AND benchmarked dramatically better than tiny
# on the Chemistry test window (Rutherford and "aath hazaar" (8000)
# both correct; see output/clip2-bigmodel-check.md). large-v3 stays
# selectable — if its snapshot ever lands, --model large-v3 just works.
MODEL_SNAPSHOTS = {
    "tiny": _snapshot("faster-whisper-tiny"),
    "small": _snapshot("faster-whisper-small"),
    "medium": _snapshot("faster-whisper-medium"),
    "large-v3": _snapshot("faster-whisper-large-v3"),
}
DEFAULT_MODEL = "medium"

HERE = os.path.dirname(os.path.abspath(__file__))
OUT_DIR = os.path.join(HERE, "output")
WORK_DIR = os.path.join(HERE, "work")

# Words that tend to mark a hook / payoff moment (English + Roman Urdu +
# Urdu script). Matching is case-insensitive on the stripped token.
HOOK_WORDS = {
    "wow", "amazing", "secret", "trick", "why", "how", "if", "guess",
    "wait", "look", "listen", "remember", "important", "never", "always",
    "wrong", "right", "answer", "question", "challenge", "imagine",
    "believe", "stop", "watch", "see", "now",
    "dekho", "suno", "agar", "kyun", "kyon", "kaise", "socho", "raaz",
    "hairan", "kamaal", "jawab", "sawaal", "galat", "sahi", "yaad",
    "kabhi", "ruk", "ruko",
    "کیوں", "کیسے", "دیکھو", "سنو", "اگر", "سوچو", "راز", "حیران",
    "جواب", "سوال", "غلط", "صحیح", "یاد", "کبھی", "رک", "حیرت",
}
DIGIT_RE = re.compile(r"[0-9\u0660-\u0669\u06f0-\u06f9]")
SENT_END = (".", "?", "!", "۔", "؟")


def run(cmd, **kw):
    print("  $", " ".join(str(c) for c in cmd[:6]),
          "..." if len(cmd) > 6 else "", flush=True)
    subprocess.run(cmd, check=True, **kw)


def probe(video):
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-select_streams", "v:0",
         "-show_entries", "stream=width,height,r_frame_rate",
         "-show_entries", "format=duration", "-of", "json", video],
        capture_output=True, text=True, check=True)
    d = json.loads(out.stdout)
    st = d["streams"][0]
    num, den = st["r_frame_rate"].split("/")
    return {"duration": float(d["format"]["duration"]),
            "width": st["width"], "height": st["height"],
            "fps": float(num) / float(den)}


# ---------------------------------------------------------------------------
# Stage 1+2: audio + transcription (cached). We decode the WAV ourselves and
# hand whisper a numpy array — the installed PyAV build chokes on
# faster-whisper's file-path kwargs.
# ---------------------------------------------------------------------------

def extract_audio(video, wav_path):
    run(["ffmpeg", "-y", "-v", "error", "-i", video,
         "-vn", "-ac", "1", "-ar", "16000", wav_path])


def load_wav(path):
    with wave.open(path, "rb") as w:
        assert w.getframerate() == 16000 and w.getnchannels() == 1
        frames = w.readframes(w.getnframes())
    return np.frombuffer(frames, dtype=np.int16).astype(np.float32) / 32768.0


def transcribe(samples, workdir, lang_arg, model_name=DEFAULT_MODEL):
    snap = MODEL_SNAPSHOTS.get(model_name) or model_name
    model = WhisperModel(snap, device="cpu", compute_type="int8")
    detected, prob, _all = model.detect_language(samples)
    if lang_arg != "auto":
        lang = lang_arg
    elif detected in ("ur", "hi"):
        # Spoken Urdu and Hindi are the same language; tiny can only split
        # them by script statistics. ClipKaro is Urdu-first, so we take the
        # Urdu script rendering. (Override any time with --language.)
        lang = "ur"
    else:
        lang = detected
    print(f"  detected={detected} (p={prob:.2f}) -> transcribing as '{lang}'")

    # Cache is keyed by MODEL + language (v1.4): a transcript made by
    # tiny must never be served when large-v3 was requested, or the other
    # way round. (Pre-v1.4 caches were named transcript-<lang>.json and
    # are simply ignored now.)
    cache = os.path.join(workdir, f"transcript-{model_name}-{lang}.json")
    if os.path.exists(cache):
        print(f"  using cached transcript {cache}")
        return json.load(open(cache, encoding="utf-8")), lang
    segments, _info = model.transcribe(
        samples, language=lang, word_timestamps=True, beam_size=1,
        vad_filter=False)
    words = []
    for seg in segments:
        for w in seg.words or []:
            words.append({"start": float(w.start), "end": float(w.end),
                          "word": w.word})
    print(f"  {len(words)} words")
    with open(cache, "w", encoding="utf-8") as f:
        json.dump(words, f, ensure_ascii=False)
    return words, lang


# ---------------------------------------------------------------------------
# Stage 3: highlight scoring (same transparent recipe as v1)
# ---------------------------------------------------------------------------

def rms_curve(samples, sr=16000, win_s=0.5):
    win = int(sr * win_s)
    n = max(1, len(samples) // win)
    trimmed = samples[: n * win].reshape(n, win)
    return np.sqrt(np.mean(trimmed ** 2, axis=1)), win_s


def seg_rms(curve, win_s, start, end):
    i0 = max(0, int(start / win_s))
    i1 = min(len(curve), max(i0 + 1, int(math.ceil(end / win_s))))
    return float(np.mean(curve[i0:i1]))


def clean_tok(w):
    return w.strip().strip(".,;:\"'()[]").lower()


def hook_count(words):
    n = 0
    for w in words:
        if "?" in w["word"] or "!" in w["word"] or "؟" in w["word"]:
            n += 2
        if clean_tok(w["word"]) in HOOK_WORDS:
            n += 1
    return n


def build_candidates(words, duration, min_len, max_len):
    cands = []
    last_start = -10.0
    for i, w in enumerate(words):
        if w["start"] < last_start + 3.0:
            continue
        last_start = w["start"]
        start = w["start"]
        ends = [j for j in range(i, len(words))
                if min_len <= words[j]["end"] - start <= max_len]
        if not ends:
            continue
        best = None
        for j in ends:
            gap = (words[j + 1]["start"] - words[j]["end"]) \
                if j + 1 < len(words) else 9
            natural = gap >= 0.35 or words[j]["word"].rstrip().endswith(SENT_END)
            key = (0 if natural else 1, abs((words[j]["end"] - start) - 45.0))
            if best is None or key < best[0]:
                best = (key, j)
        j = best[1]
        end = min(duration, words[j]["end"])
        if end - start < min_len:
            continue
        cands.append({"start": max(0.0, start - 0.25), "end": end + 0.3,
                      "words": words[i:j + 1]})
    return cands


def score_candidates(cands, curve, win_s):
    for c in cands:
        dur = c["end"] - c["start"]
        c["energy"] = seg_rms(curve, win_s, c["start"], c["end"])
        c["density"] = len(c["words"]) / dur
        c["hooks"] = hook_count(c["words"])

    def norm(key):
        vals = [c[key] for c in cands]
        lo, hi = min(vals), max(vals)
        for c in cands:
            c[key + "_n"] = 0.0 if hi == lo else (c[key] - lo) / (hi - lo)

    for k in ("energy", "density", "hooks"):
        norm(k)
    for c in cands:
        c["score"] = (0.40 * c["energy_n"] + 0.30 * c["density_n"]
                      + 0.30 * c["hooks_n"])
    return cands


def pick_top(cands, n):
    picked = []
    for c in sorted(cands, key=lambda x: -x["score"]):
        overlap = any(
            min(c["end"], p["end"]) - max(c["start"], p["start"])
            > 0.2 * min(c["end"] - c["start"], p["end"] - p["start"])
            for p in picked)
        if not overlap:
            picked.append(c)
        if len(picked) == n:
            break
    return sorted(picked, key=lambda x: x["start"])


# ---------------------------------------------------------------------------
# Virality score + reasons (feature 2)
# ---------------------------------------------------------------------------

def sentences(words):
    out, cur = [], []
    for w in words:
        cur.append(w)
        if w["word"].rstrip().endswith(SENT_END):
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def first_number(words):
    for w in words:
        if DIGIT_RE.search(w["word"]):
            return w["word"].strip()
    return None


def virality(cand, curve, win_s, vid_mean, vid_std):
    start, end = cand["start"], cand["end"]
    words = cand["words"]
    reasons = []
    score = 40.0 * cand["score"]  # base: highlight rank within this video

    # hook question in the first 15 s
    q = next((w for w in words
              if ("?" in w["word"] or "؟" in w["word"])
              and w["start"] - start <= 15), None)
    if q is not None:
        score += 15
        reasons.append("Opens with a hook question in the first "
                       f"{q['start'] - start:.0f}s")
    # hard number / fact
    num = first_number(words)
    if num:
        score += 15
        reasons.append(f"Contains a hard number/fact: '{num}'")
    # energy peak (loudest 3 s vs segment average)
    seg = curve[int(start / win_s):int(end / win_s)]
    if len(seg) >= 6:
        peak3 = max(float(np.mean(seg[i:i + 6])) for i in range(len(seg) - 5))
        ratio = peak3 / max(1e-6, float(np.mean(seg)))
    else:
        ratio = 1.0
    if ratio >= 1.25:
        pts = min(15.0, (ratio - 1.0) * 30)
        score += pts
        reasons.append(f"Energy peak {ratio:.1f}x the clip average "
                       "(emphasis moment)")
    # emotional spike vs the whole video
    if len(seg):
        z = (float(np.max(seg)) - vid_mean) / max(1e-6, vid_std)
        if z >= 2.0:
            score += 10
            reasons.append("Contains one of the loudest spikes of the "
                           "whole video (emotional peak)")
    # fast start — no dead air
    first5 = [w for w in words if w["start"] - start <= 5]
    if len(first5) / 5.0 >= cand["density"]:
        score += 5
        reasons.append("Fast, dense opening — no dead air in the first 5s")
    if cand["words"][-1]["word"].rstrip().endswith(SENT_END):
        reasons.append("Ends on a complete thought, not mid-sentence")
    return int(round(max(0.0, min(100.0, score)))), reasons


# ---------------------------------------------------------------------------
# Auto hook title + posting draft (feature 4)
# ---------------------------------------------------------------------------

JUNK_RE = re.compile(r"^[^0-9A-Za-z\u0600-\u06FF]+$")


def clean_sentence(words):
    toks = [w["word"].strip() for w in words]
    toks = [t for t in toks if t and not JUNK_RE.match(t)]
    while toks and len(toks[0]) <= 1 and not DIGIT_RE.search(toks[0]):
        toks.pop(0)
    return toks


def hook_title(cand):
    pairs = [(raw, clean_sentence(raw)) for raw in sentences(cand["words"])]
    pairs = [(raw, clean) for raw, clean in pairs if len(clean) >= 3]
    if not pairs:
        toks = clean_sentence(cand["words"])[:8]
        return " ".join(toks)
    start = cand["start"]
    # (a) a question early in the clip
    for raw, clean in pairs:
        if raw[0]["start"] - start <= 15 and \
                any("?" in w["word"] or "؟" in w["word"] for w in raw):
            return " ".join(clean[:10])
    # (b) a sentence carrying a number/fact
    for _raw, clean in pairs:
        if any(DIGIT_RE.search(t) for t in clean):
            return " ".join(clean[:10])
    # (c) the opening sentence
    return " ".join(pairs[0][1][:10])


def post_draft(title, cand, lang, stem):
    text = " ".join(w["word"].strip() for w in cand["words"])
    excerpt = text[:150].rsplit(" ", 1)[0]
    tags = "#Shorts #Education #Science"
    if lang == "ur":
        tags += " #Urdu"
    return (f"TITLE: {title}\n\n"
            f"CAPTION:\n{title}\n{excerpt}...\n"
            f"Full lesson in the long video — follow for part 2!\n\n"
            f"{tags}\n")


# ---------------------------------------------------------------------------
# Motion-tracked crop + punch-in zooms: REMOVED in v1.2 (Sehrish's
# feedback — the moving picture annoyed her). Reframe is a static solid
# pad for every clip (v1.3); see render_clip.
# ---------------------------------------------------------------------------


# ---------------------------------------------------------------------------
# Roman transliteration + optional karaoke captions (v1.3, Sehrish's
# ruling: caption language option with Roman Urdu and Roman Hindi ONLY —
# never Urdu script on screen; default stays OFF / text-free).
#
# The transliteration is fully local and deterministic: a Perso-Arabic
# character map + context rules for و / ی + a small dictionary of common
# words whose short vowels the script leaves unwritten. Urdu script does
# not write short vowels, so output is a phonetic approximation — words
# outside the dictionary can miss vowels (e.g. سال -> "sal" without the
# dictionary entry "saal"). Anything already Latin/digits passes through;
# any Arabic-script character that survives the map is stripped, so the
# burned captions can never contain Urdu/Devanagari script.
# ---------------------------------------------------------------------------

_BG_HEX = "0B0B10"  # solid pad background — flat, constant, zero content

_URDU_MAP = {
    "ا": "a", "آ": "aa", "أ": "a", "إ": "i", "ٱ": "a",
    "ب": "b", "پ": "p", "ت": "t", "ٹ": "t", "ث": "s",
    "ج": "j", "چ": "ch", "ح": "h", "خ": "kh",
    "د": "d", "ڈ": "d", "ذ": "z", "ر": "r", "ڑ": "r",
    "ز": "z", "ژ": "zh", "س": "s", "ش": "sh", "ص": "s",
    "ض": "z", "ط": "t", "ظ": "z", "ع": "a", "غ": "gh",
    "ف": "f", "ق": "q", "ک": "k", "گ": "g", "ل": "l",
    "م": "m", "ن": "n", "ں": "n", "ہ": "h", "ھ": "h", "ة": "h",
    "ؤ": "o", "ئ": "i", "ء": "", "ٰ": "a",
    "۔": ".", "؟": "?", "،": ",", "؛": ";",
}
# و and ی are context-dependent, handled in to_roman():
#   و -> word-initial "w" (Roman Hindi "v"), otherwise "o"
#   ی -> word-initial "y", otherwise "i" ; ے -> "e"

_ROMAN_COMMON = {  # words whose vowels the script hides — spell them out
    "یہ": "yeh", "یہی": "yehi", "وہ": "woh", "ہے": "hai", "ہیں": "hain",
    "کہ": "keh", "کا": "ka", "کی": "ki", "کے": "ke", "کو": "ko",
    "میں": "mein", "سے": "se", "تو": "to", "بھی": "bhi", "اور": "aur",
    "نہیں": "nahin", "ایک": "ek", "ان": "in", "اس": "is", "اسے": "ise",
    "پر": "par", "تھا": "tha", "تھی": "thi", "تھے": "the",
    "گا": "ga", "گی": "gi", "گے": "ge", "نا": "na", "ہر": "har",
    "کیا": "kya", "کیوں": "kyun", "کیسے": "kaise", "اگر": "agar",
    "لیکن": "lekin", "اب": "ab", "جب": "jab", "تب": "tab", "جو": "jo",
    "ہی": "hi", "نے": "ne", "والا": "wala", "والے": "wale", "والی": "wali",
    "کتاب": "kitaab", "سال": "saal", "سو": "sau", "دو": "do",
    "تین": "teen", "چار": "chaar", "پانچ": "paanch", "ہزار": "hazaar",
    "بہت": "bohat", "چھوٹی": "chhoti", "چھوٹے": "chhote", "چھوٹا": "chhota",
    "بڑا": "bara", "بڑی": "bari", "بڑے": "bare", "سوال": "sawaal",
    "جواب": "jawaab", "اندر": "andar", "باہر": "bahar", "اوپر": "upar",
    "نیچے": "neeche", "ہوتا": "hota", "ہوتی": "hoti", "ہوتے": "hote",
    "کرتا": "karta", "کرتی": "karti", "کرتے": "karte", "رہا": "raha",
    "رہی": "rahi", "رہے": "rahe", "گیا": "gaya", "گئی": "gayi",
    "آتا": "aata", "جاتا": "jata", "دیکھو": "dekho", "سنو": "suno",
    "سوچو": "socho", "اسلام": "islam", "لیے": "liye", "ہمارا": "hamara",
    "تمہارا": "tumhara", "میرا": "mera", "تیرا": "tera", "اپنا": "apna",
    "اچھا": "achha", "اچھے": "achhe", "پھر": "phir",
    "ابھی": "abhi", "کبھی": "kabhi", "وہی": "wohi", "یہاں": "yahan",
    "وہاں": "wahan", "کہاں": "kahan", "یعنی": "yaani", "تقریبا": "taqreeban",
    "تقریباً": "taqreeban", "تقریبن": "taqreeban", "اصل": "asal",
    "اسل": "asal", "چیز": "cheez", "چیس": "cheez", "ذرا": "zara",
}
# Roman Hindi shares the engine; spelling variants only (व -> "v" is
# handled by the word-initial و rule below).
_ROMAN_HINDI_COMMON = dict(_ROMAN_COMMON, **{
    "وہ": "vah", "وہی": "vahi", "وہاں": "wahan",
})

_AR_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩",
                           "01234567890123456789")
_AR_SCRIPT_RE = re.compile(r"[\u0600-\u06FF\u0750-\u077F\uFB50-\uFDFF\uFE70-\uFEFF]")


def to_roman(word, mode):
    """Transliterate one transcript token to Latin script (never returns
    Arabic/Devanagari script). mode: 'roman-urdu' | 'roman-hindi'."""
    # transcript tokens carry leading spaces — strip before any lookup,
    # or the common-word dictionary and the word-initial rules never hit
    w = word.strip().translate(_AR_DIGITS)
    punct = ""
    while w and w[-1] in "۔؟،؛.!?,":
        punct = _URDU_MAP.get(w[-1], w[-1] if w[-1] in ".!?," else "") + punct
        w = w[:-1]
    table = _ROMAN_HINDI_COMMON if mode == "roman-hindi" else _ROMAN_COMMON
    if w in table:
        return table[w] + punct
    if not _AR_SCRIPT_RE.search(w):
        return w + punct  # already Latin / digits / plain punctuation
    out = []
    chars = [c for c in w if c != "\u200c"]  # drop ZWNJ
    for i, c in enumerate(chars):
        if c == "و":
            out.append(("v" if mode == "roman-hindi" else "w")
                       if i == 0 else "o")
        elif c == "ی":
            out.append("y" if i == 0 else "i")
        elif c == "ے":
            out.append("e")
        elif c == "\u0651":  # shadda: double the previous consonant
            if out and out[-1]:
                out.append(out[-1][-1])
        elif "\u064b" <= c <= "\u0652" or c == "\u0670":
            continue  # other vowel marks: script leaves them ambiguous
        else:
            out.append(_URDU_MAP.get(c, ""))
    roman = "".join(out)
    roman = _AR_SCRIPT_RE.sub("", roman)  # hard guarantee: Latin only
    return roman + punct


def ass_time(t):
    t = max(0.0, t)
    h = int(t // 3600)
    m = int((t % 3600) // 60)
    s = t % 60
    return f"{h}:{m:02d}:{s:05.2f}"


def write_roman_ass(cand, mode, path):
    """Karaoke captions for one clip, in Roman script, from the cached
    transcript's word timings. Modest size (Fontsize 32 at PlayRes
    1080x1920 — roughly half of v1.1's 58), sitting in the solid band
    below the centred slide."""
    start = cand["start"]
    words = [w for w in cand["words"]
             if w["end"] > start and w["start"] < cand["end"]]
    # chunk into caption lines: break on sentence end, >2.6 s, or 5 words
    lines, cur = [], []
    for w in words:
        cur.append(w)
        dur = w["end"] - cur[0]["start"]
        if (w["word"].rstrip().endswith(SENT_END) or dur >= 2.6
                or len(cur) >= 5):
            lines.append(cur)
            cur = []
    if cur:
        lines.append(cur)
    events = []
    for li, line in enumerate(lines):
        ls = line[0]["start"] - start
        le = line[-1]["end"] - start
        if li + 1 < len(lines):
            le = max(le, min(le + 0.15,
                             lines[li + 1][0]["start"] - start))
        parts = []
        for w in line:
            k = max(1, int(round((w["end"] - w["start"]) * 100)))
            tok = to_roman(w["word"].strip(), mode)
            if not tok:
                continue
            if clean_tok(w["word"]) in HOOK_WORDS or DIGIT_RE.search(tok):
                tok = "{\\1c&H000080FF&}" + tok + "{\\1c&H0000FFFF&}"
            parts.append("{\\k%d}%s" % (k, tok))
        if parts:
            events.append((ls, le, " ".join(parts)))
    with open(path, "w", encoding="utf-8") as f:
        f.write("[Script Info]\nScriptType: v4.00+\n"
                "PlayResX: 1080\nPlayResY: 1920\n\n"
                "[V4+ Styles]\n"
                "Format: Name, Fontname, Fontsize, PrimaryColour, "
                "SecondaryColour, OutlineColour, BackColour, Bold, "
                "Italic, Underline, StrikeOut, ScaleX, ScaleY, Spacing, "
                "Angle, BorderStyle, Outline, Shadow, Alignment, "
                "MarginL, MarginR, MarginV, Encoding\n"
                "Style: K,Noto Sans,32,&H0000FFFF,&H00FFFFFF,&H00000000,"
                "&H64000000,-1,0,0,0,100,100,0,0,1,3,1,2,40,40,190,1\n\n"
                "[Events]\n"
                "Format: Layer, Start, End, Style, Name, MarginL, "
                "MarginR, MarginV, Effect, Text\n")
        for ls, le, text in events:
            f.write(f"Dialogue: 0,{ass_time(ls)},{ass_time(le)},K,,0,0,0,,"
                    f"{text}\n")
    return len(events)


# ---------------------------------------------------------------------------
# Rendering: one static solid-pad piece per clip (v1.3). piece_bounds /
# the concat path remain only so multi-piece inputs still work; with no
# punch windows every clip is a single piece.
# ---------------------------------------------------------------------------

def piece_bounds(cand, punches):
    pts = [cand["start"]]
    for a, b in punches:
        pts += [a, b]
    pts.append(cand["end"])
    pts = sorted(set(pts))
    out = []
    for a, b in zip(pts, pts[1:]):
        zoom = 1.12 if any(pa - 0.01 <= a and b <= pb + 0.01
                           for pa, pb in punches) else 1.0
        out.append((a, b, zoom))
    return out


def render_clip(video, meta, cand, mode, track, punches, title, out_path,
                workdir, tag, ass_name=None):
    pieces = piece_bounds(cand, punches)
    part_files = []
    for pi, (a, b, zoom) in enumerate(pieces):
        dur = b - a
        part = os.path.join(workdir, f"{tag}-part{pi}.mp4")
        # v1.3: static SOLID pad ONLY. The full source frame is centred
        # over a flat solid background colour — the pad filter paints a
        # constant colour, so the background has zero motion or content
        # (v1.2's blurred mirror of the source still moved on screen).
        # No time-varying expression anywhere: framing cannot drift, pan
        # or zoom. Optional Roman captions (ass_name) are the only text
        # ever written onto the picture, and only when --captions is on.
        fg_w = int(1080 * zoom)
        fc = (f"[0:v]scale={fg_w}:-2,"
              f"pad=1080:1920:(ow-iw)/2:(oh-ih)/2:color=0x{_BG_HEX}")
        if ass_name:
            fc += f",ass={ass_name}"
        fc += "[v]"
        graph = os.path.join(workdir, f"{tag}-graph{pi}.txt")
        with open(graph, "w") as f:
            f.write(fc)
        run(["ffmpeg", "-y", "-v", "error",
             "-ss", f"{a:.2f}", "-i", video, "-t", f"{dur:.2f}",
             "-filter_complex_script", graph, "-map", "[v]", "-map", "0:a",
             "-r", "30", "-c:v", "libx264", "-preset", "veryfast",
             "-crf", "20", "-c:a", "aac", "-b:a", "128k",
             "-video_track_timescale", "30000", part],
            cwd=workdir)
        part_files.append(part)
    if len(part_files) == 1:
        os.replace(part_files[0], out_path)
        return
    lst = os.path.join(workdir, f"{tag}-concat.txt")
    with open(lst, "w") as f:
        for p in part_files:
            f.write(f"file '{os.path.basename(p)}'\n")
    run(["ffmpeg", "-y", "-v", "error", "-f", "concat", "-safe", "0",
         "-i", lst, "-c", "copy", "-movflags", "+faststart", out_path],
        cwd=workdir)


# ---------------------------------------------------------------------------

def main():
    ap = argparse.ArgumentParser(description="ClipKaro v1.6 — local AI clipper")
    ap.add_argument("input")
    ap.add_argument("--clips", type=int, default=3)
    ap.add_argument("--min-len", type=float, default=30.0)
    ap.add_argument("--max-len", type=float, default=60.0)
    # Kept for CLI compatibility; v1.3 output is always static solid pad.
    ap.add_argument("--reframe", choices=["auto", "crop", "pad"],
                    default="pad")
    ap.add_argument("--language", default="auto")
    # v1.6 (Sehrish's order 2026-11-18, supersedes v1.5): subtitles ON
    # again — sahi Roman Urdu is the DEFAULT. Her condition: subtitles
    # must be 100% theek, so every clip's captions get a human-eye QA
    # pass before delivery. Roman Hindi stays available; Urdu script
    # and Devanagari are never offered or burned.
    ap.add_argument("--captions", choices=["off", "roman-urdu",
                                           "roman-hindi"],
                    default="roman-urdu")
    # v1.4: transcription model — default is the BIG model (large-v3).
    ap.add_argument("--model", choices=["tiny", "small", "medium",
                                        "large-v3"], default=DEFAULT_MODEL)
    ap.add_argument("--output-dir", default=OUT_DIR)
    args = ap.parse_args()

    video = os.path.abspath(args.input)
    stem = os.path.splitext(os.path.basename(video))[0]
    workdir = os.path.join(WORK_DIR, stem)
    os.makedirs(workdir, exist_ok=True)
    os.makedirs(args.output_dir, exist_ok=True)

    t0 = time.time()
    meta = probe(video)
    print(f"[clipkaro] input {video} ({meta['duration']:.1f}s, "
          f"{meta['width']}x{meta['height']})", flush=True)

    print("[1/6] extracting audio...")
    wav_path = os.path.join(workdir, "audio.wav")
    if not os.path.exists(wav_path):
        extract_audio(video, wav_path)
    samples = load_wav(wav_path)

    print(f"[2/6] transcribing (faster-whisper {args.model}, "
          f"word timestamps)...")
    t = time.time()
    words, lang = transcribe(samples, workdir, args.language, args.model)
    print(f"      took {time.time() - t:.0f}s")
    if len(words) < 20:
        sys.exit("transcript too sparse to clip from — aborting")

    print("[3/6] scoring highlight candidates...")
    curve, win_s = rms_curve(samples)
    vid_mean, vid_std = float(np.mean(curve)), float(np.std(curve))
    cands = build_candidates(words, meta["duration"],
                             args.min_len, args.max_len)
    print(f"      {len(cands)} candidate windows")
    if not cands:
        sys.exit("no candidate windows in the requested length range")
    score_candidates(cands, curve, win_s)
    picks = pick_top(cands, args.clips)

    print("[4/6] analysing picks (virality, titles)...")
    results = []
    for rank, c in enumerate(picks, 1):
        vscore, reasons = virality(c, curve, win_s, vid_mean, vid_std)
        title = hook_title(c)
        # v1.3 (Sehrish's feedback): static picture only — solid-pad
        # reframe for every clip, no motion-tracked crop, no punch-in
        # zooms, no blurred background. --reframe is still accepted for
        # CLI compatibility but no longer changes the output.
        punches = []
        track, conc = None, None
        mode = "solid-pad"
        text = " ".join(w["word"] for w in c["words"])[:110]
        print(f"  #{rank} {c['start']:.1f}-{c['end']:.1f}s "
              f"virality={vscore} mode={mode} "
              f"(motion-in-window={conc if conc is None else round(conc, 2)}, "
              f"punches={len(punches)}) :: {text}...")
        results.append({"cand": c, "virality": vscore, "reasons": reasons,
                        "title": title, "punches": punches, "mode": mode,
                        "track": track, "conc": conc})

    print(f"[5/6] rendering Shorts (captions={args.captions})...")
    clips_json = []
    for rank, r in enumerate(results, 1):
        c = r["cand"]
        out_path = os.path.join(args.output_dir, f"{stem}-short{rank}.mp4")
        ass_name = None
        if args.captions != "off":
            ass_path = os.path.join(workdir, f"s{rank}-roman.ass")
            n_ev = write_roman_ass(c, args.captions, ass_path)
            ass_name = os.path.basename(ass_path)
            print(f"      captions: {n_ev} lines ({args.captions})")
        render_clip(video, meta, c, r["mode"], r["track"], r["punches"],
                    r["title"], out_path, workdir, f"s{rank}",
                    ass_name=ass_name)
        title_path = os.path.join(args.output_dir,
                                  f"{stem}-short{rank}.title.txt")
        post_path = os.path.join(args.output_dir,
                                 f"{stem}-short{rank}.post.txt")
        with open(title_path, "w", encoding="utf-8") as f:
            f.write(r["title"] + "\n")
        with open(post_path, "w", encoding="utf-8") as f:
            f.write(post_draft(r["title"], c, lang, stem))
        print(f"      -> {out_path}")
        clips_json.append({
            "rank": rank,
            "file": os.path.basename(out_path),
            "source": os.path.basename(video),
            "start_s": round(c["start"], 2), "end_s": round(c["end"], 2),
            "duration_s": round(c["end"] - c["start"], 2),
            "language": lang,
            "asr_model": args.model,
            "captions": args.captions,
            "reframe_mode": r["mode"],
            "motion_in_window": None if r["conc"] is None
            else round(r["conc"], 3),
            "highlight_score": round(c["score"], 3),
            "virality_score": r["virality"],
            "virality_reasons": r["reasons"],
            "hook_title": r["title"],
            "punch_in_at_s": [round(a - c["start"], 2)
                              for a, _ in r["punches"]],
            "transcript": " ".join(w["word"] for w in c["words"]),
        })

    out_json = os.path.join(args.output_dir, "clips.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(clips_json, f, ensure_ascii=False, indent=2)
    print(f"[6/6] wrote {out_json}")
    print(f"[clipkaro] done in {time.time() - t0:.0f}s total")


if __name__ == "__main__":
    main()
